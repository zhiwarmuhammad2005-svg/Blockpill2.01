package com.example.blackpill;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;

public final class ModEffects {
    private ModEffects() {}

    // Black Pill state: makes you shorter. Black Pill music plays while you have it.
    public static final Holder<MobEffect> SHRUNK = Registry.registerForHolder(
            BuiltInRegistries.MOB_EFFECT,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "shrunk"),
            new ShrunkEffect());

    // White Pill state: no size change. White Pill music plays while you have it.
    public static final Holder<MobEffect> UPLIFTED = Registry.registerForHolder(
            BuiltInRegistries.MOB_EFFECT,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "uplifted"),
            new UpliftedEffect());

    public static void init() {
        // Touching this class registers the effects.
    }
}
