package com.example.blackpill;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * White Pill state marker. It changes nothing by itself: it is what the music and the
 * Black Pill / White Pill switching rules look for (the same way Shrunk is the Black Pill's marker).
 * It is deliberately a plain effect, so it never touches the player's size.
 */
public class UpliftedEffect extends MobEffect {
    public UpliftedEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xF4F4FA);
    }
}
