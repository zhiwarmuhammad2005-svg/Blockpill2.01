package com.example.blackpill;

import java.util.List;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;

public final class ModItems {
    private ModItems() {}

    public static final ResourceKey<Item> BLACK_PILL_KEY = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "black_pill"));

    public static final Item BLACK_PILL = Registry.register(
            BuiltInRegistries.ITEM,
            BLACK_PILL_KEY,
            new Item(new Item.Properties()
                    .setId(BLACK_PILL_KEY)
                    .stacksTo(16)
                    .useCooldown(1.0f)
                    // Always edible, no hunger or saturation.
                    .food(new FoodProperties.Builder()
                            .nutrition(0)
                            .saturationModifier(0.0f)
                            .alwaysEdible()
                            .build(),
                            Consumable.builder()
                                    .consumeSeconds(1.0f)
                                    .animation(ItemUseAnimation.EAT)
                                    // Plain eating sound. The pill song is NOT played here any more:
                                    // the consumable sound plays more than once while eating, which
                                    // caused the song to start twice. Music is handled by PillMusic.
                                    .sound(SoundEvents.GENERIC_EAT)
                                    .hasConsumeParticles(true)
                                    .onConsume(new ApplyStatusEffectsConsumeEffect(List.of(
                                            // Blindness, 20 seconds
                                            new MobEffectInstance(MobEffects.BLINDNESS, 20 * 20, 0),
                                            // Shrunk (0.5 blocks shorter), 80 seconds. This is also the
                                            // Black Pill state: its music loops while this effect is active.
                                            new MobEffectInstance(ModEffects.SHRUNK, 20 * 80, 0))))
                                    .build())));

    public static final ResourceKey<Item> WHITE_PILL_KEY = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "white_pill"));

    public static final Item WHITE_PILL = Registry.register(
            BuiltInRegistries.ITEM,
            WHITE_PILL_KEY,
            new Item(new Item.Properties()
                    .setId(WHITE_PILL_KEY)
                    .stacksTo(16)
                    .useCooldown(1.0f)
                    // Same shape as the Black Pill: always edible, 1 s to eat, no hunger of its own
                    // (the Saturation effect below fills the bar).
                    .food(new FoodProperties.Builder()
                            .nutrition(0)
                            .saturationModifier(0.0f)
                            .alwaysEdible()
                            .build(),
                            Consumable.builder()
                                    .consumeSeconds(1.0f)
                                    .animation(ItemUseAnimation.EAT)
                                    .sound(SoundEvents.GENERIC_EAT)
                                    .hasConsumeParticles(true)
                                    .onConsume(new ApplyStatusEffectsConsumeEffect(List.of(
                                            // Saturation, applied once (0.5 s): refills hunger right away
                                            new MobEffectInstance(MobEffects.SATURATION, 10, 0),
                                            // Strength I, 120 seconds
                                            new MobEffectInstance(MobEffects.STRENGTH, 20 * 120, 0),
                                            // Uplifted, 120 seconds. This is the White Pill state: its
                                            // music loops while this effect is active. No size change.
                                            new MobEffectInstance(ModEffects.UPLIFTED, 20 * 120, 0))))
                                    .build())));

    public static final ResourceKey<Item> GIANT_HAMMER_KEY = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(BlackPillMod.MOD_ID, "giant_hammer"));

    public static final Item GIANT_HAMMER = Registry.register(
            BuiltInRegistries.ITEM,
            GIANT_HAMMER_KEY,
            new GiantHammerItem(new Item.Properties()
                    .setId(GIANT_HAMMER_KEY)
                    .rarity(Rarity.EPIC)
                    // Heavy melee weapon: ~8 damage, slow swing.
                    .sword(ToolMaterial.IRON, 5.0f, -3.0f)));

    public static void init() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FOOD_AND_DRINKS)
                .register(output -> {
                    output.accept(BLACK_PILL);
                    output.accept(WHITE_PILL);
                });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(output -> output.accept(GIANT_HAMMER));
    }
}
