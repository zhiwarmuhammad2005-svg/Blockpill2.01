package com.example.blackpill;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;

/**
 * One looping, non-positional music track. It stops itself the moment the local player no longer
 * has the effect that owns it (effect ended, milk, death, /effect clear, other pill eaten, left the world).
 * Client only: this class must never be loaded on a dedicated server.
 */
final class PillMusicInstance extends AbstractTickableSoundInstance {
    private final Holder<MobEffect> ownerEffect;

    PillMusicInstance(SoundEvent sound, Holder<MobEffect> ownerEffect) {
        super(sound, SoundSource.MUSIC, SoundInstance.createUnseededRandom());
        this.ownerEffect = ownerEffect;
        this.looping = true;
        this.delay = 0;
        this.volume = 1.0f;
        this.pitch = 1.0f;
        // Heard the same everywhere, not tied to a position in the world.
        this.relative = true;
        this.attenuation = SoundInstance.Attenuation.NONE;
    }

    @Override
    public void tick() {
        var player = Minecraft.getInstance().player;
        if (player == null || !player.hasEffect(ownerEffect)) {
            stop();
        }
    }

    /** Public wrapper, because stop() is protected. */
    void halt() {
        stop();
    }
}
