package com.example.blackpill;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;

/**
 * Server side. Keeps the two pills from overlapping: the pill eaten most recently wins.
 *
 * Black state = Shrunk effect.  White state = Uplifted effect.
 * Each tick we remember which states a player had last tick. If both are present now, the one that
 * is new this tick is the pill just eaten, so the other pill's effects are removed.
 */
public final class PillEvents {
    private PillEvents() {}

    // UUID -> { hadShrunkLastTick, hadUpliftedLastTick }
    private static final Map<UUID, boolean[]> PREVIOUS = new HashMap<>();

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(PillEvents::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        Set<UUID> online = new HashSet<>();

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            UUID id = player.getUUID();
            online.add(id);
            boolean[] previous = PREVIOUS.computeIfAbsent(id, key -> new boolean[2]);

            boolean black = player.hasEffect(ModEffects.SHRUNK);
            boolean white = player.hasEffect(ModEffects.UPLIFTED);

            if (black && white) {
                if (!previous[0]) {
                    // Black Pill was just eaten: end the White Pill.
                    clearWhite(player);
                    white = false;
                } else if (!previous[1]) {
                    // White Pill was just eaten: end the Black Pill (this also returns your size to normal).
                    clearBlack(player);
                    black = false;
                } else {
                    // Both appeared together (for example /effect give): keep Black, drop White.
                    clearWhite(player);
                    white = false;
                }
            }

            previous[0] = black;
            previous[1] = white;
        }

        // Forget players who left.
        PREVIOUS.keySet().retainAll(online);
    }

    private static void clearBlack(ServerPlayer player) {
        player.removeEffect(ModEffects.SHRUNK);
        player.removeEffect(MobEffects.BLINDNESS);
    }

    private static void clearWhite(ServerPlayer player) {
        player.removeEffect(ModEffects.UPLIFTED);
        player.removeEffect(MobEffects.STRENGTH);
    }
}
