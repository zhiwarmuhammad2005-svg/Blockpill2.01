package com.example.blackpill;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

/** Client-only entry point. Not loaded on a dedicated server. */
public class BlackPillClient implements ClientModInitializer {
    @Override
    public void onInitialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> PillMusic.tick(client));
    }
}
