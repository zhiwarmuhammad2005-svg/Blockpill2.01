# Blockpill 1.2.0 (Fabric, Minecraft 26.3)

Mod ID: `blackpill`. Three items.

## Black Pill
Always edible, 1 s to eat, stacks to 16. Gives Blindness (20 s) and Shrunk (80 s, about 0.5 blocks shorter; the size
setting scales width too, so you are also about 0.17 blocks narrower, not 0.3).
**Black state = the Shrunk effect.** The Black Pill track (`sounds/pill_song.ogg`) loops while you have it.
Recipe: coal + ink sac + bone meal -> 2.

## White Pill
Always edible, 1 s to eat, stacks to 16. Gives Saturation (instant refill), Strength I (120 s) and Uplifted (120 s).
No size change. **White state = the Uplifted effect.** The White Pill track (`sounds/white_pill_song.ogg`) loops while you have it.
Recipe: bone meal + sugar + glowstone dust -> 2.

## How the music works
- Music is played by the client, one looping instance at a time, decided only by your own effects:
  Shrunk only -> Black track, Uplifted only -> White track, neither -> silence.
- Switching stops the old track before the new one starts, so tracks never overlap and a playing track is never started again.
- Music uses the Music volume slider. Only you hear your own pill music.

## How effects end
- Timer: Blindness after 20 s, Shrunk after 80 s, Strength and Uplifted after 120 s. Music stops when its state effect ends.
- Eating the other pill: the server removes the previous pill's effects. White removes Shrunk + Blindness (size returns to
  normal). Black removes Uplifted + Strength.
- Also ends everything it removes: milk, `/effect clear`, death (respawning starts with no pill effects and no music).
- Saturation is instant, so it is not removed when you switch.
- Note: switching also removes any Strength or Blindness from other sources (for example a potion).
- Size change is done on the server by an effect attribute, so everyone sees it. Only the music is client side.

## Giant Hammer
Heavy melee weapon (about 8 damage, slow swing). Right-click toggles giant mode (3 blocks tall, cheapest villager trades,
mobs leave you alone, plays `sounds/hammer_song.ogg`). It is separate from the pills and not changed by them.
Recipe: 5 iron ingots + 1 black pill + 1 stick.

## Replacing a song
Replace the matching .ogg in `src/main/resources/assets/blackpill/sounds/` (Vorbis format) and rebuild.
`white_pill_song.ogg` is the Chronoshift track (2:30); `pill_song.ogg` is the Black Pill track (1:19).

## Install
1. Minecraft 26.3 with Fabric Loader 0.19.5 or newer (Java 25).
2. Fabric API for 26.3 (0.165.0+26.3 or newer).
3. Put Fabric API and `blockpill-1.2.0.jar` in your `mods` folder.

## Build
Needs JDK 25: `./gradlew build`. The jar is `build/libs/blockpill-1.2.0.jar` (not the `-sources` jar).
No JDK? Push this folder to GitHub. `.github/workflows/build.yml` builds it; the jar is under Actions > latest run > Artifacts.
